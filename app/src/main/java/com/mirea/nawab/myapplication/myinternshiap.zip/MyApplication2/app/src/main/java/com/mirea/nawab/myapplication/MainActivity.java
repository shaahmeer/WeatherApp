package com.mirea.nawab.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.os.StrictMode;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);


        recyclerView=findViewById(R.id.recycle);
        String[] name={"moscow","karachi","texas"};
        
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        try {
            recyclerView.setAdapter(new adapter(name));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}