package com.mirea.nawab.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

import retrofit2.Response;

public class adapter extends RecyclerView.Adapter<adapter.viewholder>{
    API api;
    String[] data;

    public adapter(String[] data) throws IOException {
        this.data = data;
        this.api = new API();
    }

    @NonNull
    @NotNull
    @Override
    public viewholder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view= inflater.inflate(R.layout.single_item,parent,false);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull viewholder holder, int position) {
        String title=data[position];
        try {
            CityModel city = API.getApi().getCity(title).execute().body();
            Float temp = city.main.temp - 273.15F;
            holder.textView.setText(title);
            holder.textView1.setText(city.main.pressure.toString());
            holder.textView3.setText(temp.toString());
            holder.textView4.setText(city.weather.get(0).main);




        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return data.length;
    }

    public class viewholder extends RecyclerView.ViewHolder{

        private TextView textView;
        private TextView textView1;
        private TextView textView3;
        private TextView textView4;



        public viewholder(@NonNull @NotNull View itemView) {
            super(itemView);

            textView=(TextView)itemView.findViewById(R.id.text3);
            textView1=(TextView)itemView.findViewById(R.id.text1);
            textView3=(TextView)itemView.findViewById(R.id.text);
            textView4=(TextView)itemView.findViewById(R.id.text4);
        }
    }


}
